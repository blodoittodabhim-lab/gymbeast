# GymBeast – Convert Web App to APK

## Method 1: Capacitor (Recommended – Free)

### Prerequisites
- Node.js 18+
- Android Studio + Android SDK
- Java 17+

### Steps

```bash
# 1. Create project folder
mkdir gymbeast && cd gymbeast

# 2. Init npm project
npm init -y

# 3. Install Capacitor + Android
npm install @capacitor/core @capacitor/cli @capacitor/android

# 4. Create www/ folder and put gymbeast-app.html inside as index.html
mkdir www
cp gymbeast-app.html www/index.html

# 5. Init Capacitor
npx cap init GymBeast com.gymbeast.app --web-dir www

# 6. Add Android platform
npx cap add android

# 7. Sync
npx cap sync android

# 8. Open in Android Studio
npx cap open android
```

### In Android Studio:
- Go to **Build → Generate Signed Bundle/APK**
- Choose **APK**
- Create a keystore (or use existing)
- Select **release** build variant
- Click **Finish** — APK saved to `android/app/release/`

---

## Method 2: PWA Builder (Easiest – Online Tool)

1. Host `gymbeast-app.html` on any static host (GitHub Pages, Netlify)
2. Go to **https://www.pwabuilder.com**
3. Enter your URL → Analyze
4. Click **Build My PWA → Android**
5. Download the APK package

---

## Method 3: WebViewGold (Paid, No-Code)

- Buy WebViewGold on CodeCanyon (~$29)
- Upload HTML file, set app name/icon
- Build APK directly from their dashboard

---

## Required Permissions (add to AndroidManifest.xml)

```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.INTERNET"/>
<uses-feature android:name="android.hardware.camera" android:required="false"/>
```

---

## App Details

| Field | Value |
|-------|-------|
| App Name | GymBeast |
| Package | com.gymbeast.app |
| Min SDK | 24 (Android 7+) |
| Target SDK | 34 (Android 14) |
| Permissions | Camera, Internet |
| Orientation | Portrait |

---

## Features in the App

- ✅ Phone number login (OTP flow)
- ✅ AI Push-Up counter (camera + TensorFlow.js MoveNet)
- ✅ AI Squat counter (camera + TensorFlow.js MoveNet)
- ✅ Daily rep tracking & history
- ✅ Weekly progress bar chart
- ✅ Streak tracking
- ✅ Black & Red gym aesthetic
- ✅ Dashboard, History, Profile screens
- ✅ Works offline (simulation mode if no camera)
- ✅ Persistent local storage for workout logs
